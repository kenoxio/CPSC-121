#include <iostream>
#include <stdlib.h>
#include <time.h>
using namespace std;

int main(){
    int diceAmount;
    cout << "How many dice or dies do you want to throw? # of die: ";
    cin >> diceAmount;
    cout << "You decided to put in " << diceAmount << " dies or dice." << endl;
    int randomVal = 0;
    randomVal = rand();
    cout << "Random value " << randomVal << endl;
}